import random


class TicTacToe:
    def __init__(self):
        # TODO: Set up the board to be '-'
        self.board = []

    def print_instructions(self):
        # TODO: Print the instructions to the game
        return

    def print_board(self):
        # TODO: Print the board
        return

    def is_valid_move(self, row, col):
        # TODO: Check if the move is valid
        return

    def place_player(self, player, row, col):
        # TODO: Place the player on the board
        return

    def take_manual_turn(self, player):
        # TODO: Ask the user for a row, col until a valid response
        #  is given them place the player's icon in the right spot
        return

    def take_turn(self, player):
        # TODO: Simply call the take_manual_turn function
        return

    def check_col_win(self, player):
        # TODO: Check col win
        return False

    def check_row_win(self, player):
        # TODO: Check row win
        return False

    def check_diag_win(self, player):
        # TODO: Check diagonal win
        return False

    def check_win(self, player):
        # TODO: Check win
        return False

    def check_tie(self):
        # TODO: Check tie
        return False

    def play_game(self):
        # TODO: Play game
        return

