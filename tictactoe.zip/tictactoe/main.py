from tictactoe import *

game = TicTacToe()
game.play_game()